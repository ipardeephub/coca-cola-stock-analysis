CREATE TABLE ko_stock_data (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date_time TEXT,
    open REAL,
    high REAL,
    low REAL,
    close REAL,
    volume INTEGER
);
