import yfinance as yf
import pandas as pd
from datetime import datetime

ticker = "KO"
ko = yf.Ticker(ticker)
data = ko.history(period="1d", interval="1m")
filename = f"ko_stock_data_{datetime.now().strftime('%Y-%m-%d')}.csv"
data.to_csv(filename)
print(f"Data for {ticker} saved to {filename}")
