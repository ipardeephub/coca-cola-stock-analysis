# Coca-Cola Stock – Live and Updated

## 👨‍💼 Domain: Financial Analyst

This project tracks Coca-Cola's (KO) stock price in real-time, stores the data, analyzes trends, and predicts short-term price movements using Python, SQL, and Machine Learning.
